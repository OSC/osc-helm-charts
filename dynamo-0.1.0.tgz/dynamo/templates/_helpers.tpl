{{/*
Expand the name of the chart.
*/}}
{{- define "dynamo.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "dynamo.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "dynamo.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "dynamo.labels" -}}
helm.sh/chart: {{ include "dynamo.chart" . }}
{{ include "dynamo.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "dynamo.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dynamo.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "dynamo.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "dynamo.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
image-puller labels
*/}}
{{- define "dynamo.image-puller.labels" -}}
helm.sh/chart: {{ include "dynamo.chart" . }}
{{ include "dynamo.image-puller.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
image-puller selector labels
*/}}
{{- define "dynamo.image-puller.selectorLabels" -}}
app.kubernetes.io/name: image-puller
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/* Image tag helper */}}
{{- define "dynamo.image" -}}
{{- $tag := printf "%s-osc-r%s" (.Values.image.tag | default .Chart.AppVersion) .Values.image.release }}
{{- printf "%s/%s:%s" .Values.global.imagePullSecret.registry .Values.image.repository $tag }}
{{- end }}

{{- define "dynamo.runtime.version" -}}
{{- $versionParts := splitList "-" .Chart.AppVersion }}
{{- first $versionParts }}
{{- end -}}

{{- define "dynamo.openai.urls" -}}
{{- $urls := list }}
{{- range $name, $model := .Values.global.models }}
    {{- $urls = append $urls (printf "http://%s-frontend-frontend.%s.svc.cluster.local:8000/v1" $name $.Release.Namespace) }}
{{- end }}
{{- $urls | join ";" }}
{{- end }}

{{- define "dynamo.openai.configs" -}}
{{- $configs := dict -}}
{{- $index := 0 -}}
{{- range $name, $model := .Values.global.models }}
    {{- $model_ids := list ($model.alias | default $model.model) -}}
    {{- $config := dict "enabled" true "prefix_id" "" "model_ids" $model_ids "connection_type" "external" -}}
    {{- $_ := set $configs ($index | toString ) $config -}}
    {{- $index = add $index 1 -}}
{{- end }}
{{- $configs | toJson -}}
{{- end }}

{{- define "dynamo.keepalive.content" -}}
MODEL_NAME=${1}
echo "Wait for model to be available"
until curl --fail -sS http://localhost:8000/v1/models | jq -e '.data | length > 0'; do
    echo "Model not ready yet, waiting..."
    sleep 10
done
echo "Model ready, begin keep alive"
data=$(printf '{"model":"%s","chat_template_kwargs":{"enable_thinking":false},"messages":[{"role": "user", "content": "Test"}]}' "$MODEL_NAME")
while true; do
    timeout 30 curl --fail -sS -o /dev/null http://localhost:8000/v1/chat/completions -H "Content-Type: application/json" -H "x-request-id: keepalive" -d "$data"
    ret=$?
    if [ $ret -ne 0 ]; then
        echo "keep alive failed, ret=$ret"
        exit 1
    fi
    sleep {{ .Values.keepalive.interval }}
done
{{- end -}}
